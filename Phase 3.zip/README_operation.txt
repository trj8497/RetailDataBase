To use this application, simply enter commands into the command line.
The application either prompt you with a list of options, in which case you can enter the number to select it (e.g. 1-n),
or it will ask you to enter data in an open ended type of dialog. In this case, it will prompt you with the format
you should enter it in.